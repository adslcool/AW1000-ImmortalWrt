# openluat
Model | Platform | USB  | PCIe 
--- | --- | --- | ---
air724ug | unisoc |✔ usb(ecm,rndis) | ✘

# huawei
Model | Platform | USB  | PCIe 
--- | --- | --- | ---
s10 | hisilicon |✔ usb(rndis) | ✘
mt5700m-cn | hisilicon |✔ usb(ecm,ncm) | ✘
mt5710_cn | hisilicon |✔ usb(ecm,ncm) | ✘
mh5000-31 | hisilicon |✔ usb(ecm,ncm) | ✘
mh5000-82 | unisoc |✔ usb(ecm,ncm,rndis) | ✘
mh5000-82m | unisoc |✔ usb(ecm,ncm,rndis) | ✘

# quectel
Model | Platform | USB  | PCIe 
--- | --- | --- | ---
em05 | lte |✔ usb(qmi,ecm,mbim,rndis) | ✘
em05-cn | lte |✔ usb(qmi,ecm,mbim,rndis) | ✘
ep06 | lte |✔ usb(qmi,ecm,mbim,rndis) | ✘
em12 | lte |✔ usb(qmi,ecm,mbim,rndis) | ✘
em120k | lte12 |✔ usb(qmi,ecm,mbim,rndis) | ✘
em160r-gl | lte12 |✔ usb(qmi,ecm,mbim,rndis) | ✘
ag598eeu | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✘
rg200u-cn | unisoc |✔ usb(ecm,mbim,rndis,ncm) | ✘
rg801 | hisilicon |✔ usb(ecm,rndis,ncm) | ✘
rm500u-cn | unisoc |✔ usb(ecm,mbim,rndis,ncm) | ✘
rm500u-cnv | unisoc |✔ usb(ecm,mbim,rndis,ncm) | ✘
rm500u-ea | unisoc |✔ usb(ecm,mbim,rndis,ncm) | ✘
rm500s-ce | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rm500q-cn | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✘
rm510q-gl | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rm510q-glha | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✘
rg500q-ea | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rm500q-ae | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rm500q-gl | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rm502q-ae | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rm502q-gl | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rm505q-ae | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✘
rm520n-cn | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✘
rm520n-eu | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rm520n-gl | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rm520f-gl | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rm520f-bl | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rm521f-gl | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rm530n-gl | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rm551e-gl | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rg501q-eu | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rg520n-eu | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rg520n-eb | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
mh8001-eu | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rg520f-eu | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rg520f-eb | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rg520f-jo | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rg530f-na | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
rg650v-eu | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,gobinet,mbim)
ec20f | lte |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✘
ec25 | lte |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✘
eg25 | lte |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✘
ec21 | lte |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✘
ec200a | lte |✔ usb(ecm,mbim,rndis,ncm) | ✘

# fibocom
Model | Platform | USB  | PCIe 
--- | --- | --- | ---
fm650-cn | unisoc |✔ usb(ecm,mbim,rndis,ncm) | ✘
fm350-gl | mediatek |✔ usb(rndis) | ✔ pcie(mbim)
fm350-gl-00 | mediatek |✔ usb(rndis) | ✘
fm350r-gl | mediatek |✔ usb(rndis) | ✔ pcie(mbim)
rw350r-gl | mediatek |✔ usb(rndis) | ✔ pcie(mbim)
fm150-ae | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,mbim)
fm160-cn | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,mbim)
fm160-eau | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,mbim)
fm160-na | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi,mbim)
fm170-eau | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis) | ✔ pcie(qmi,mbim)
fm190w-gl | qualcomm |✔ usb(qmi,gobinet,ecm,mbim,rndis,ncm) | ✔ pcie(qmi)
l610-eu | unisoc |✔ usb(ecm,rndis,ncm) | ✘
nl668 | lte |✔ usb(ecm,rndis,ncm) | ✘
nl678 | lte |✔ usb(qmi,ecm,rndis,ncm) | ✘

# meig
Model | Platform | USB  | PCIe 
--- | --- | --- | ---
srm815 | qualcomm |✔ usb(ecm,rndis,ncm) | ✘
srm825 | qualcomm |✔ usb(ecm,rndis,ncm) | ✘
srm825n | qualcomm |✔ usb(ecm,rndis,ncm) | ✘
srm821 | unisoc |✔ usb(ecm,rndis,ncm) | ✘

# sierra
Model | Platform | USB  | PCIe 
--- | --- | --- | ---
em9190 | qualcomm |✔ usb(mbim,rmnet) | ✔ pcie(mbim,rmnet)
em9291 | qualcomm |✔ usb(mbim,rmnet) | ✔ pcie(mbim,rmnet)
mc7354 | lte |✔ usb(qmi) | ✘
mc7355 | lte |✔ usb(qmi) | ✘

# telit
Model | Platform | USB  | PCIe 
--- | --- | --- | ---
fn990a40 | qualcomm |✔ usb(mbim,rndis,qmi,ecm) | ✔ pcie(mbim,qmi)

# simcom
Model | Platform | USB  | PCIe 
--- | --- | --- | ---
simcom_a8200_serias | asrmicro |✔ usb(ecm,rndis) | ✘
a8200c-m2 | asrmicro |✔ usb(ecm,rndis) | ✘
a7605c | lte |✔ usb(ecm,rndis,auto) | ✘
simcom_d8200g | qualcomm |✔ usb(qmi,rndis) | ✘
simcom_sim8200ea-m2 | qualcomm |✔ usb(qmi,rndis) | ✘
simcom_sim8202g-m2 | qualcomm |✔ usb(qmi,rndis,mbim) | ✘
simcom_sim8380g-m2 | qualcomm |✔ usb(qmi,rndis) | ✔ pcie(qmi)

# foxconn
Model | Platform | USB  | PCIe 
--- | --- | --- | ---
t77w968 | qualcomm |✔ usb(qmi,mbim) | ✘
t99w175 | qualcomm |✔ usb(mbim,rmnet) | ✔ pcie(mbim)
t99w373 | qualcomm |✔ usb(mbim,rmnet) | ✔ pcie(mbim)
t99w368 | qualcomm |✔ usb(mbim,rmnet) | ✔ pcie(mbim)
t99w640 | qualcomm |✘ | ✔ pcie(mbim)

# thales
Model | Platform | USB  | PCIe 
--- | --- | --- | ---
mv32-w-a | qualcomm |✔ usb(mbim) | ✘
mv32-w-b | qualcomm |✔ usb(mbim,rmnet) | ✘

# neoway
Model | Platform | USB  | PCIe 
--- | --- | --- | ---
n510m | unisoc |✔ usb(ecm) | ✘

# gosuncn
Model | Platform | USB  | PCIe 
--- | --- | --- | ---
me3630-w | lte |✔ usb(ecm) | ✘
gm800 | qualcomm |✔ usb(qmi,ecm,mbim,rndis) | ✔ pcie(mbim)
