'use strict';
'require baseclass';

return baseclass.extend({
	manufacturers: {
		gosuncn: 'GosunCN',
		foxconn: 'Foxconn',
		quectel: 'Quectel',
		simcom: 'Simcom',
		sierra: 'Sierra Wireless',
		fibocom: 'Fibocom',
		meig: 'Meig',
		huawei: 'Huawei',
		neoway: 'Neoway',
		telit: 'Telit',
		thales: 'Thales',
		openluat: 'OpenLuat',
		nk: "Tom's Love"
	},
	platforms: {
		lte: 'LTE',
		lte12: 'LTE12',
		qualcomm: 'Qualcomm',
		mediatek: 'MediaTek',
		unisoc: 'Unisoc',
		intel: 'Intel'
	},
	modes: {
		ecm: 'ECM',
		mbim: 'MBIM',
		qmi: 'QMI',
		ncm: 'NCM',
		rndis: 'RNDIS'
	},
	disabled_features: {
		DialMode: 'Dial Mode',
		RatPrefer: 'Rat Prefer',
		IMEI: 'Set IMEI',
		NeighborCell: 'Neighbor Cell',
		LockBand: 'Lock Band',
		RebootModem: 'Reboot Modem',
		AtDebug: 'AT Debug'
	}
});
