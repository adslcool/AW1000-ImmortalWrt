
local NXFS = require "nixio.fs"
local SYS = require "luci.sys"
local HTTP = require "luci.http"
local DISP = require "luci.dispatcher"
local UTIL = require "luci.util"
local fs = require "luci.openclash"
local uci = require("luci.model.uci").cursor()

m = SimpleForm("openclash",translate("OpenClash"))
m.description = translate("A Mihomo(Clash) Client For OpenWrt")
m.reset = false
m.submit = false

m:section(SimpleSection).template = "openclash/status"
if fs.uci_get_config("config", "oix_token") and fs.uci_get_config("config", "oix_show_info_page") == "1" then
	m:append(Template("openclash/oixcloud"))
end
m:append(Template("openclash/myip"))
m:append(Template("openclash/developer"))
m:append(Template("openclash/update"))
m:append(Template("openclash/config_edit"))
m:append(Template("openclash/config_upload"))

return m

